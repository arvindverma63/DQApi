<p>Your OTP for login is: {{ $otp }}</p>
