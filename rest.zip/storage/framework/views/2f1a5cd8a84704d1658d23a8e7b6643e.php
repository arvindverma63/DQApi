<p>Your OTP for login is: <?php echo e($otp); ?></p>
<?php /**PATH C:\Users\pc\Desktop\dicui\resources\views/emails/otp.blade.php ENDPATH**/ ?>