<p>Your OTP for login is: <?php echo e($otp); ?></p>
<?php /**PATH C:\Users\pc\Desktop\_test\resources\views/emails/otp.blade.php ENDPATH**/ ?>