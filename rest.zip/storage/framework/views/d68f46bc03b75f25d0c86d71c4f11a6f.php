<p>Your OTP for login is: <?php echo e($otp); ?></p>
<?php /**PATH /home/u972632477/domains/dicui.org/public_html/rest/resources/views/emails/otp.blade.php ENDPATH**/ ?>